MartinaPy Python Module
=======================

Developer Team:
'mmarinozzi@esriitalia.it;gpalombi@esriitalia.it'

Software requirements:
- Python 2.7
- ArcGIS 10.4
- ArcGISx6410.4

Setup procedure:
================
1 - Unzip MartinaPy.zip file in a user folder.
2 - Edit all the batch files (CreateModule.bat, CreateModuleWin32.bat, InstallModule.bat,
    InstallModuleWin32.bat)
    and update the user folder path along with the path specified on step 1.
3 - Open up a command shell window.
4 - Run CreateModule.bat.
    Upon success continue with next step, otherwise report error messages to
    Esri Italia technical support.
5 - Run InstallModule.bat.
    Upon success continue with next step, otherwise report error messages to
    Esri Italia technical support.
6 - Run CreateModuleWin32.bat.
    Upon success continue with next step, otherwise report error messages to
    Esri Italia technical support.
7 - Run InstallModuleWin32.bat.
    Upon success continue with Check Library Procedure, otherwise report error messages to
    Esri Italia technical support.


Check Library Procedure:
=========================
Check up from Python Interpreter

1 - Start PyCharm (or PyScripter 64bit).
2 - Open Python Console window.
3 - Inside Python Console window type: >> import martinapy
4 - Inside Python Console window type: >> martinapy.checkInstall()
    Upon success you should receive the following message:
    >>>
    SUCCESS:
    Python module martinapy successfully installed!
    (1, ['SUCCESS:\nPython module martinapy successfully installed!'])
    >>>


Check up from ArcGIS
1 - Start ArcMap (or ArcCatalog).
2 - Open Python Console window.
3 - Inside Python Console window type: >> import martinapy
4 - Inside Python Console window type: >> martinapy.checkInstall()
    Upon success you should receive the following message:
    >>>
    SUCCESS:
    Python module martinapy successfully installed!
    (1, ['SUCCESS:\nPython module martinapy successfully installed!'])
    >>>

