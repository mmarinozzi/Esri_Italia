import arcpy
from xml.dom.minidom import parse
import xml.dom.minidom
import os
import datetime
import cx_Oracle

oraclehost = "srvgeodb.sinapsi.mil.it"
oracleport = 1521
oracletns = "EGDB"
oracleuser = "GESTIONALE"
oraclepassword = "1q2w3e4r5t6y7U"

# ######################################################################

def checkInstall():
    rc = 1
    msgLst = []
    msg = "SUCCESS:\nPython module martinapy successfully installed!"

    try:
        import pip
        installed_packages = pip.get_installed_distributions()
        installed_packages_list = []
        for i in installed_packages:
            installed_packages_list.append(i.key)
        #print installed_packages_list
        if not 'martinapy' in installed_packages_list:
            rc = -1
            msg = "ERROR:\nCouldn't find Python module martinapy!"
    except:
        rc = -11
        msg = "ERROR:\nCouldn't read Python modules!"

    print msg
    msgLst.append(msg)
    retLst = (rc,msgLst)

    return retLst

# ######################################################################

def deleteBilFile(name,extensionvalue):
    arcpy.Delete_management(name.replace(extensionvalue,"")+".bil")
    arcpy.Delete_management(name.replace(extensionvalue,"")+".bil.aux.xml")
    arcpy.Delete_management(name.replace(extensionvalue,"")+".bil.ovr")
    arcpy.Delete_management(name.replace(extensionvalue,"")+".bil.xml")
    arcpy.Delete_management(name.replace(extensionvalue,"")+".hdr")
    arcpy.Delete_management(name.replace(extensionvalue,"")+".prj")
    arcpy.Delete_management(name.replace(extensionvalue,"")+".stx")

# ######################################################################

def addAttributes(attributesXML,attributesfile,mosaicdataset, Expression):
    DOMTree = xml.dom.minidom.parse(attributesXML)
    DOMTreeAttributes = xml.dom.minidom.parse(attributesfile)
    collection = DOMTree.documentElement
    collectionAttributes = DOMTreeAttributes.documentElement
    sections = collection.getElementsByTagName("section")
    for section in sections:
        sectionid = section.getAttribute("id")
        sectiontype = section.getAttribute("type")
        sectionsAttributes = collectionAttributes.getElementsByTagName(sectionid)
        fields = section.getElementsByTagName("field")
        for field in fields:
            fieldname = field.getAttribute("name")
            fieldtype = field.getAttribute("type")
            fieldformat = field.getAttribute("format")
            fieldval=""
            if (sectiontype=="with_tags"):
                sectionsTags = collectionAttributes.getElementsByTagName("Tag")
                for sectionsTag in sectionsTags:
                    tagNames = sectionsTag.getElementsByTagName("TagName")
                    for tagName in tagNames:
                        if (tagName.firstChild.nodeValue==fieldname):
                            tagValues = sectionsTag.getElementsByTagName("TagValue")
                            for tagValue in tagValues:
                                fieldval = tagValue.firstChild.nodeValue
            else:
                for sectionsAttribute in sectionsAttributes:
                    sectionValues = sectionsAttribute.getElementsByTagName(fieldname)
                    for sectionValue in sectionValues:
                        fieldval = sectionValue.firstChild.nodeValue

            if fieldval!="":
                rows=arcpy.UpdateCursor(mosaicdataset, Expression)
                for r in rows:
                    r = setValue(fieldname.replace(" ",""),fieldtype,fieldformat,fieldval,r)
                    rows.updateRow(r)
                del r
                del rows

# ######################################################################

def setValue(fieldname,fieldtype,fieldcast,fieldval,r):

    if fieldtype.lower()=="text":
        fvalue=str(fieldval)

    if fieldtype.lower()=="double":
        fvalue=float(fieldval)

    if fieldtype.lower()=="vectorindouble":
        vals = fieldval.split(";+;")
        position = int(fieldcast)
        if position<0: position=vals.__len__()+position
        fvalue=float(vals[position])

    if fieldtype.lower()=="long":
        fvalue=long(fieldval)

    if fieldtype.lower()=="int":
        fvalue=int(fieldval)

    if fieldtype.lower()=="datetime":
        if "." in fieldval: fieldval = fieldval[:fieldval.rindex(".")]
        fvalue = datetime.datetime.strptime(fieldval,fieldcast)

    r.setValue(fieldname,fvalue)
    return r

# ######################################################################

def removelastRaster(name,mosaicdatasetpath,lastinsert,lastmosaic):
    Expression = "Name like '"+ lastmosaic+"%'"
    if (name.startswith(lastinsert) and lastmosaic!=""):
        rows=arcpy.UpdateCursor(mosaicdatasetpath, Expression)
        for r in rows:
            rows.deleteRow(r)
        del rows

# ######################################################################

def addLogStart(username, product, startingDate):
    dsn = cx_Oracle.makedsn(oraclehost,oracleport,oracletns)
    connection = cx_Oracle.connect(oracleuser,oraclepassword,dsn)
    cursor = cx_Oracle.Cursor(connection)
    sqlstring = "insert into INGESTION_LOG (UTENTE, PRODOTTO, INIZIO, INVIATI, PROCESSATI, SCARTATI) VALUES ('"+username+"','"+product+"',TO_TIMESTAMP('"+startingDate+"','YYYY-DD-MM HH24:MI'),0,0,0)"
    cursor.execute(sqlstring)
    connection.commit()
    cursor.close()
    connection.close()

# ######################################################################

def addLogSend(username, product, startingDate):
    dsn = cx_Oracle.makedsn(oraclehost,oracleport,oracletns)
    connection = cx_Oracle.connect(oracleuser,oraclepassword,dsn)
    cursor = cx_Oracle.Cursor(connection)
    sqlstring = "UPDATE INGESTION_LOG SET INVIATI=INVIATI+1 WHERE UTENTE='"+username+"' AND PRODOTTO='"+product+"' AND INIZIO=TO_TIMESTAMP('"+startingDate+"','YYYY-DD-MM HH24:MI')"
    cursor.execute(sqlstring)
    connection.commit()
    cursor.close()
    connection.close()

# ######################################################################

def addLogResult(username, product, startingDate, success):
    dsn = cx_Oracle.makedsn(oraclehost,oracleport,oracletns)
    connection = cx_Oracle.connect(oracleuser,oraclepassword,dsn)
    cursor = cx_Oracle.Cursor(connection)
    fieldname = "PROCESSATI"
    if not success: fieldname = "SCARTATI"
    sqlstring = "UPDATE INGESTION_LOG SET "+fieldname+"="+fieldname+"+1 WHERE UTENTE='"+username+"' AND PRODOTTO='"+product+"' AND INIZIO=TO_TIMESTAMP('"+startingDate+"','YYYY-DD-MM HH24:MI')"
    cursor.execute(sqlstring)
    connection.commit()
    cursor.close()
    connection.close()

# ######################################################################

def addLogEnd(username, product, startingDate):
    dsn = cx_Oracle.makedsn(oraclehost,oracleport,oracletns)
    connection = cx_Oracle.connect(oracleuser,oraclepassword,dsn)
    cursor = cx_Oracle.Cursor(connection)
    endDate = datetime.datetime.now().strftime("%Y-%d-%m %H:%M")
    sqlstring = "UPDATE INGESTION_LOG SET FINE=TO_TIMESTAMP('"+endDate+"','YYYY-DD-MM HH24:MI') WHERE UTENTE='"+username+"' AND PRODOTTO='"+product+"' AND INIZIO=TO_TIMESTAMP('"+startingDate+"','YYYY-DD-MM HH24:MI')"
    cursor.execute(sqlstring)
    connection.commit()
    cursor.close()
    connection.close()

# ######################################################################

