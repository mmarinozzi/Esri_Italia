#-------------------------------------------------------------------------------
# Name:        setup
# Purpose:     Setup martina.py module
#
# Author:      mmarinozzi
#
# Created:     26/09/2013
# Copyright:   (c) mmarinozzi 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------

def main():
    from distutils.core import setup
    setup(name='martinapy',
          version='1.0',
          description='Martina Python Distribution Utilities',
          author='Esri Italia Martina developers',
          author_email='mmarinozzi@esriitalia.it;gpalombi@esriitalia.it',
          url='http://www.esriitalia.it/',
          py_modules=['martinapy'],
          )

if __name__ == '__main__':
    main()
